#ifndef SONG_H
#define SONG_H

#include "MusicItem.h"

class Song : public MusicItem {
public:
    Song(const std::string& title, const std::string& artist, int rating,
         const std::string& genre);

    const std::string& getGenre() const;

    std::string describe() const override;
    std::string typeName() const override;

private:
    std::string genre_;
};

#endif
