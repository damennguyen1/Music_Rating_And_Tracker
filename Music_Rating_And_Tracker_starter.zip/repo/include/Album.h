#ifndef ALBUM_H
#define ALBUM_H

#include "MusicItem.h"

class Album : public MusicItem {
public:
    Album(const std::string& title, const std::string& artist, int rating,
          int trackCount);

    int getTrackCount() const;

    std::string describe() const override;
    std::string typeName() const override;

private:
    int trackCount_;
};

#endif
