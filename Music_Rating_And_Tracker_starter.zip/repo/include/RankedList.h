#ifndef RANKEDLIST_H
#define RANKEDLIST_H

#include <algorithm>
#include <stdexcept>
#include <vector>

// Template: an ordered list of at most five items.
// Planned uses: RankedList<std::string> (artists), RankedList<Song>,
// RankedList<Album>. T must support copying and operator==.
template <typename T>
class RankedList {
public:
    static constexpr int MAX_SIZE = 5;

    // Inserts item at a 1-based position. Throws on a bad position or duplicate.
    void add(const T& item, int position) {
        if (position < 1 || position > MAX_SIZE)
            throw std::out_of_range("Position must be 1-5");
        if (std::find(items_.begin(), items_.end(), item) != items_.end())
            throw std::invalid_argument("Already ranked");
        if (position - 1 > static_cast<int>(items_.size()))
            throw std::out_of_range("Fill earlier positions first");
        items_.insert(items_.begin() + (position - 1), item);
        if (static_cast<int>(items_.size()) > MAX_SIZE)
            items_.pop_back();
    }

    void removeAt(int position) {
        if (position < 1 || position > static_cast<int>(items_.size()))
            throw std::out_of_range("No item at that position");
        items_.erase(items_.begin() + (position - 1));
    }

    const std::vector<T>& getAll() const { return items_; }
    int size() const { return static_cast<int>(items_.size()); }

private:
    std::vector<T> items_;
};

#endif
