#ifndef MUSICITEM_H
#define MUSICITEM_H

#include <string>

// Abstract base class for anything the user can rate.
// MusicItem enforces the rules for title, artist, and rating.
class MusicItem {
public:
    MusicItem(const std::string& title, const std::string& artist, int rating);
    virtual ~MusicItem() = default;

    const std::string& getTitle() const;
    const std::string& getArtist() const;
    int getRating() const;
    void setRating(int newRating);   // throws std::invalid_argument if not 1-10

    // Pure virtual: each derived class decides how it is described.
    virtual std::string describe() const = 0;
    virtual std::string typeName() const = 0;

    // Same title and artist (ignoring case) counts as the same item.
    bool operator==(const MusicItem& other) const;

private:
    std::string title_;
    std::string artist_;
    int rating_;
};

#endif
