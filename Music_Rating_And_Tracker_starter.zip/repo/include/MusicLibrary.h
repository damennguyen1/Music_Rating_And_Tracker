#ifndef MUSICLIBRARY_H
#define MUSICLIBRARY_H

#include <memory>
#include <string>
#include <vector>

#include "Album.h"
#include "MusicItem.h"
#include "Song.h"

// Owns every song and album and enforces the library rules:
// valid entries only, no duplicates, search, and sort.
class MusicLibrary {
public:
    void addSong(const std::string& title, const std::string& artist, int rating,
                 const std::string& genre);
    void addAlbum(const std::string& title, const std::string& artist, int rating,
                  int trackCount);

    // Overloaded search: all types, or filtered to "Song" / "Album".
    std::vector<MusicItem*> search(const std::string& text) const;
    std::vector<MusicItem*> search(const std::string& text, const std::string& type) const;

    void sortByRating(std::vector<MusicItem*>& list) const;
    void sortAlphabetically(std::vector<MusicItem*>& list) const;

    std::vector<MusicItem*> getAll() const;
    std::size_t size() const;

private:
    void addUnique(std::unique_ptr<MusicItem> item);

    std::vector<std::unique_ptr<MusicItem>> items_;
};

#endif
