#include "MusicLibrary.h"

#include <algorithm>
#include <stdexcept>

#include "Utils.h"

void MusicLibrary::addUnique(std::unique_ptr<MusicItem> item) {
    for (const auto& existing : items_) {
        if (existing->typeName() == item->typeName() && *existing == *item)
            throw std::invalid_argument("Already in library: " + item->getTitle());
    }
    items_.push_back(std::move(item));   // only reached if everything above passed
}

void MusicLibrary::addSong(const std::string& title, const std::string& artist,
                           int rating, const std::string& genre) {
    addUnique(std::make_unique<Song>(title, artist, rating, genre));
}

void MusicLibrary::addAlbum(const std::string& title, const std::string& artist,
                            int rating, int trackCount) {
    addUnique(std::make_unique<Album>(title, artist, rating, trackCount));
}

std::vector<MusicItem*> MusicLibrary::search(const std::string& text) const {
    std::vector<MusicItem*> results;
    const std::string needle = toLower(text);
    for (const auto& item : items_) {
        if (needle.empty() ||
            toLower(item->getTitle()).find(needle) != std::string::npos ||
            toLower(item->getArtist()).find(needle) != std::string::npos) {
            results.push_back(item.get());
        }
    }
    return results;
}

std::vector<MusicItem*> MusicLibrary::search(const std::string& text,
                                             const std::string& type) const {
    std::vector<MusicItem*> all = search(text);
    if (type.empty() || type == "All") return all;
    std::vector<MusicItem*> filtered;
    for (MusicItem* item : all) {
        if (item->typeName() == type) filtered.push_back(item);
    }
    return filtered;
}

void MusicLibrary::sortByRating(std::vector<MusicItem*>& list) const {
    std::stable_sort(list.begin(), list.end(), [](const MusicItem* a, const MusicItem* b) {
        if (a->getRating() != b->getRating()) return a->getRating() > b->getRating();
        return toLower(a->getTitle()) < toLower(b->getTitle());
    });
}

void MusicLibrary::sortAlphabetically(std::vector<MusicItem*>& list) const {
    std::stable_sort(list.begin(), list.end(), [](const MusicItem* a, const MusicItem* b) {
        const std::string ta = toLower(a->getTitle());
        const std::string tb = toLower(b->getTitle());
        if (ta != tb) return ta < tb;
        return toLower(a->getArtist()) < toLower(b->getArtist());
    });
}

std::vector<MusicItem*> MusicLibrary::getAll() const {
    std::vector<MusicItem*> all;
    for (const auto& item : items_) all.push_back(item.get());
    return all;
}

std::size_t MusicLibrary::size() const { return items_.size(); }
