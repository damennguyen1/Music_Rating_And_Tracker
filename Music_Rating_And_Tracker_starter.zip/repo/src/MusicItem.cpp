#include "MusicItem.h"

#include <stdexcept>

#include "Utils.h"

MusicItem::MusicItem(const std::string& title, const std::string& artist, int rating)
    : title_(title), artist_(artist), rating_(rating) {
    if (title.empty() || artist.empty())
        throw std::invalid_argument("Title and artist are required");
    if (rating < 1 || rating > 10)
        throw std::invalid_argument("Rating must be 1-10");
}

const std::string& MusicItem::getTitle() const { return title_; }
const std::string& MusicItem::getArtist() const { return artist_; }
int MusicItem::getRating() const { return rating_; }

void MusicItem::setRating(int newRating) {
    if (newRating < 1 || newRating > 10)
        throw std::invalid_argument("Rating must be 1-10");  // nothing changed yet
    rating_ = newRating;
}

bool MusicItem::operator==(const MusicItem& other) const {
    return toLower(title_) == toLower(other.title_) &&
           toLower(artist_) == toLower(other.artist_);
}
