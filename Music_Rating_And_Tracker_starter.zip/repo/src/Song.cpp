#include "Song.h"

Song::Song(const std::string& title, const std::string& artist, int rating,
           const std::string& genre)
    : MusicItem(title, artist, rating), genre_(genre) {}

const std::string& Song::getGenre() const { return genre_; }

std::string Song::describe() const {
    std::string text = "Song: " + getTitle() + " by " + getArtist() + " - " +
                       std::to_string(getRating()) + "/10";
    if (!genre_.empty()) text += " [" + genre_ + "]";
    return text;
}

std::string Song::typeName() const { return "Song"; }
