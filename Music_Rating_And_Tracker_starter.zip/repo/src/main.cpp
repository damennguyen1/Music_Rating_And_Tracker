// Console driver for the starting program.
// Shows: validation errors, runtime polymorphism, overloaded search,
// sorting, and the RankedList template. GUI and file saving are planned.

#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#include "MusicItem.h"
#include "MusicLibrary.h"
#include "RankedList.h"
#include "Song.h"

static void printAll(const std::string& heading, const std::vector<MusicItem*>& items) {
    std::cout << "\n== " << heading << " ==\n";
    if (items.empty()) std::cout << "(none)\n";
    for (const MusicItem* item : items)
        std::cout << item->describe() << '\n';   // runtime dispatch via base pointer
}

int main() {
    MusicLibrary library;

    // Task 1: add and rate music
    library.addSong("Blinding Lights", "The Weeknd", 10, "Pop");
    library.addSong("Love Story", "Taylor Swift", 7, "Country");
    library.addSong("Hello", "Adele", 8, "Soul");
    library.addAlbum("After Hours", "The Weeknd", 9, 14);
    library.addAlbum("Folklore", "Taylor Swift", 8, 16);

    // Error handling: invalid rating and duplicate are rejected, library unchanged.
    try {
        library.addSong("Bad Song", "Nobody", 11, "None");
    } catch (const std::invalid_argument& e) {
        std::cout << "Rejected: " << e.what() << '\n';
    }
    try {
        library.addSong("hello", "ADELE", 5, "Soul");
    } catch (const std::invalid_argument& e) {
        std::cout << "Rejected: " << e.what() << '\n';
    }
    std::cout << "Library size: " << library.size() << '\n';

    // Task 2: search and sort (overloaded search)
    auto weeknd = library.search("weeknd");
    library.sortByRating(weeknd);
    printAll("Search \"weeknd\", all types, by rating", weeknd);

    auto albums = library.search("", "Album");
    library.sortAlphabetically(albums);
    printAll("Albums only, A-Z", albums);

    // Task 3 (planned feature): the template that will hold Top Five lists
    RankedList<std::string> topArtists;
    topArtists.add("The Weeknd", 1);
    topArtists.add("Taylor Swift", 2);
    topArtists.add("Adele", 2);          // bumps Taylor Swift to 3
    std::cout << "\n== Top artists (RankedList<std::string>) ==\n";
    int rank = 1;
    for (const auto& name : topArtists.getAll())
        std::cout << rank++ << ". " << name << '\n';

    RankedList<Song> topSongs;
    topSongs.add(Song("Blinding Lights", "The Weeknd", 10, "Pop"), 1);
    std::cout << "\nTop song (RankedList<Song>): "
              << topSongs.getAll().front().describe() << '\n';

    return 0;
}
