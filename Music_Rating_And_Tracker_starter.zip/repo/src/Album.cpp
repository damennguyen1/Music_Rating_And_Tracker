#include "Album.h"

#include <stdexcept>

Album::Album(const std::string& title, const std::string& artist, int rating,
             int trackCount)
    : MusicItem(title, artist, rating), trackCount_(trackCount) {
    if (trackCount < 1)
        throw std::invalid_argument("Track count must be positive");
}

int Album::getTrackCount() const { return trackCount_; }

std::string Album::describe() const {
    return "Album: " + getTitle() + " by " + getArtist() + " (" +
           std::to_string(trackCount_) + " tracks) - " +
           std::to_string(getRating()) + "/10";
}

std::string Album::typeName() const { return "Album"; }
