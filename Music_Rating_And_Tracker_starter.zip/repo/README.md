# Music Rating and Tracker

COP 3003 team project. A program for keeping track of music you listen to:
add songs and albums, rate them 1-10, search and sort, and keep Top Five lists.

## Status

| Part | Status |
|---|---|
| MusicItem (abstract), Song, Album | Implemented |
| MusicLibrary (add, overloaded search, sort, duplicate check) | Implemented |
| RankedList template | Implemented (used with `std::string` and `Song` in the driver) |
| Console driver (`src/main.cpp`) | Implemented |
| Favorites class | Planned |
| FileManager (save/load) | Planned |
| Qt 6 (Widgets) GUI | Planned |

## Environment

Fill in the values used by your team.

- Operating system: _______ (example: Windows 11 / Ubuntu 24.04 / macOS 15)
- Compiler: _______ (example: g++ 13.3 / MSVC 19.4 / clang 17)
- C++ standard: C++17
- Dependencies: none for this checkpoint (standard library only). Planned: Qt 6 (Widgets module), exact version to be recorded here when the GUI is added
- CMake 3.16 or newer (optional; see the direct compile command below)

## Build and run

### Option A: CMake

```
git clone <repository URL>
cd Music_Rating_And_Tracker
cmake -S . -B build
cmake --build build
./build/music_tracker          (Windows: build\Debug\music_tracker.exe)
```

### Option B: compile directly with g++ (no CMake needed)

```
g++ -std=c++17 -Wall -Wextra -Iinclude src/*.cpp -o music_tracker
./music_tracker
```

### Option C: Visual Studio 2022 (Windows)

1. Open `MusicTracker.sln`.
2. Choose `x64` and `Debug` in the toolbar.
3. Press Ctrl+F5 (Start Without Debugging). The console window shows the demo.

The project uses the v143 toolset and C++17. If Visual Studio offers to retarget
the solution, accept it. The executable is built to `build\x64\Debug\`.

The program prints a short demonstration: two rejected entries (bad rating and
duplicate), a search sorted by rating, albums sorted A-Z, and a Top Artists list.

## Layout

```
include/   headers (MusicItem, Song, Album, RankedList, MusicLibrary, Utils)
src/       source files and the console driver (main.cpp)
docs/      design documents
```

Build folders and executables are not committed (see `.gitignore`).
